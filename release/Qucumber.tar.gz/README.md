# [Qucumber](https://github.com/bcowgill/Qucumber) - A QUnit framework for Cucumber like Behavioural Driven Development .

## Outline

* Parser of Cucumber/Gherkin language for Given/When/Then clauses.
* Scenario runner generates calls to QUnit module(), test() and asyncTest()
* Default rules and sample rules show how to configure your tests

## VERSION: 0.0 $Id$

## Quick Links

You can get the latest minimal release files from
[Coming ... Minimal Bundle](https://github.com/bcowgill/Qucumber/blob/master/release/Qucumber.tar.gz?raw=true)

## Detailed Overview

TODO

## Requirements

QUnitChainer requires:

TODO

## Files

TODO

## How to Use

TODO

## Browsers tested:

The browsers that this has currently been tested with are:

TODO

## Acknowledgements

The Author of Qucumber extends acknowledgements to the authors of QUnit

* [jQuery](http://jquery.com/)
* [QUnit](http://docs.jquery.com/QUnit)

## Contributors

Brent S.A. Cowgill

## Refs for this file

[GIT Markdown Reference](http://github.github.com/github-flavored-markdown/)
[Markdown Syntax](http://daringfireball.net/projects/markdown/syntax)
[Markdown Console](http://github.github.com/github-flavored-markdown/preview.html)